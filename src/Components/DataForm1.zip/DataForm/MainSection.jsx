import { Link, useLocation } from "react-router-dom";
import { FaCheck } from "react-icons/fa";
import { stepperArray } from "../../Redux/Action/Data";

export default function MainSection({ children }) {
  const location = useLocation();
  return (
    <>
      <div className="p-4 shadow-lg  ">
        <ol className=" flex items-center justify-center  w-full mb-4 sm:mb-5 mx-14   ">
          {stepperArray?.map((stepperData, index) => (
            <>
              <li key={index} className={`flex w-full items-center`}>
                <div
                  key={index}
                  className={`flex flex-col items-center justify-center w-10 h-10  rounded-full lg:h-12 lg:w-12 shrink-0 text-white  ${
                    index <
                    stepperArray?.findIndex((e) => e.url === location.pathname)
                      ? "bg-blue-800"
                      : "bg-blue-400"
                  }   `}
                >
                  <Link
                    to={
                      stepperArray?.findIndex(
                        (e) => e.url === location.pathname
                      ) >
                        stepperArray?.findIndex(
                          (e) => e.url === stepperData?.url
                        ) && stepperData?.url
                    }
                  >
                    <div key={index} className="relative">
                      {" "}
                      {index <
                      stepperArray?.findIndex(
                        (e) => e.url === location.pathname
                      ) ? (
                        <FaCheck className="transform transition duration-500 hover:scale-125" />
                      ) : (
                        <>
                          <span
                            className={`${
                              stepperData?.url === location?.pathname &&
                              "animate-ping absolute  h-full w-full rounded-full bg-blue-800 opacity-90"
                            }`}
                          ></span>
                          <span>{stepperData?.icon}</span>
                        </>
                      )}
                    </div>
                  </Link>
                  <div
                    key={index}
                    className="absolute top-16 text-black mt-2 pb-0 mb-3"
                  >
                    {stepperData?.name}
                  </div>
                </div>
                {index < stepperArray?.length - 1 && (
                  <span
                    className={`border-2 ${
                      index <
                      stepperArray?.findIndex(
                        (e) => e.url === location.pathname
                      )
                        ? "border-blue-800"
                        : "border-blue-400"
                    } w-full `}
                  ></span>
                )}
              </li>
            </>
          ))}
        </ol>
        <div className="flex items-center w-full justify-center  ">
          <div
            className=" w-full md:w-3/4   border p-5  mt-5 mb-5 rounded-lg
          "
          >
            {children}
          </div>
        </div>
      </div>
    </>
  );
}
